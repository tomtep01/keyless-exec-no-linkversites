----------------------------------------------------------------------------------------------------------
                                    !! **IMPORTANT | : | READ ALL** !!
----------------------------------------------------------------------------------------------------------

If You Are Having Any Problems, Check This Document For Help: https://pastebin.com/raw/vuqUBNJR

To Install New Updates, Go To This Link: https://pastebin.com/cFWfNhmW

To Add Scripts To The Script List, Just Put Your '.txt' Script Files Into The Folder Named "Scripts".

Any Extra Questions? DM Me On Discord For Help, Or Check The Pastebin For Common Questions. Peace!

----------------------------------------------------------------------------------------------------------

I Hope You Enjoy Using Vega X!

~ 1_F0 ~ 
Discord Server: https://linktr.ee/1f0

----------------------------------------------------------------------------------------------------------